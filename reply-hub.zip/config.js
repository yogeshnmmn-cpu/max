// config.js — local credentials, NOT committed to git
// Copy config.example.js → config.js and fill in your values.
export const CLIENT_ID = '257487856111-tapjev5odjmpulr4f70pscgtv25iarpu.apps.googleusercontent.com';
export const CLIENT_SECRET = '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';
